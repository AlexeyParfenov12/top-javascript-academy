var food = 'борщ';

var eatDinner = function () {
  console.log('Поел ' + food);
};
