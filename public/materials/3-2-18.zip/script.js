var food = 'пирожки';

var eatDinner = function () {
  console.log('Поел ' + food);
};
