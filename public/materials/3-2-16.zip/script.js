var eatDinner = function (drink) {
  var food = 'котлеты';
  console.log('Поел ' + food);
  console.log('Выпил ' + drink);
};
