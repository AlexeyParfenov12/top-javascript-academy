var popup = document.querySelector('.modal');
var openPopupButton = document.querySelector('.button-open');

openPopupButton.addEventListener('click', function () {
  console.log('Клик по кнопке');
});
