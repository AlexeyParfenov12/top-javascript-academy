var list = document.querySelector('.todo-list');
var items = list.querySelectorAll('.todo-list-item');

var addCheckHandler = function (item) {
  // Добавляйте код сюда
};

for (var i = 0; i < items.length; i++) {
  console.log(items[i]);
}
