var food = 'салат';

var collectContainer = function (food) {
  return function () {
    console.log('Поел ' + food);
  };
};

var schoolkidFirst = collectContainer('макароны');
